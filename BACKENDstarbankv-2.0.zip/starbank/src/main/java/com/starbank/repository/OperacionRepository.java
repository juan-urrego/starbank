package com.starbank.repository;

import com.starbank.entity.Operacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OperacionRepository extends JpaRepository<Operacion, Integer> {
}
