package com.starbank.repository;

import com.starbank.entity.Ahorro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AhorroRepository extends JpaRepository<Ahorro,Integer> {
}
