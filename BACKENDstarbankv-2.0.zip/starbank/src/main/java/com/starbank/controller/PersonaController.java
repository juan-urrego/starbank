package com.starbank.controller;

import com.starbank.entity.Persona;
import com.starbank.service.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PersonaController {
    
    @Autowired
    PersonaService service;

    @PostMapping("/personas/agregar")
    public Persona addPersona(@RequestBody Persona persona){
        return  service.savePersona(persona);
    }

    @GetMapping("/personas")
    public List<Persona> findAllPersona(){
        return  service.getPersonas();
    }

    @GetMapping("/personas/{id}")
    public Persona findPersonaById(@PathVariable int id){
        return service.getPersonaById(id);
    }

    @PutMapping("/personas/actualizar/{id}")
    public Persona updatePersona(@RequestBody Persona persona, @PathVariable int id){
        return service.updatePersona(persona, id);
    }

    @DeleteMapping("/personas/eliminar/{id}")
    public String deletePersona (@PathVariable int id){
        return service.deletePersona(id);
    }
}
