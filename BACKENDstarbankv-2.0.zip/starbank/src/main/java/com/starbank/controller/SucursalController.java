package com.starbank.controller;

import com.starbank.entity.Sucursal;
import com.starbank.service.SucursalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class SucursalController {
    @Autowired
    SucursalService service;

    @PostMapping("/sucursales/agregar")
    public Sucursal addSucursal(@RequestBody Sucursal sucursal){
        return  service.saveSucursal(sucursal);
    }

    @GetMapping("/sucursales")
    public List<Sucursal> findAllSucursal(){
        return  service.getSucursals();
    }

    @GetMapping("/sucursales/{id}")
    public Sucursal findSucursalById(@PathVariable int id){
        return service.getSucursalById(id);
    }

    @PutMapping("/sucursales/actualizar/{id}")
    public Sucursal updateSucursal(@RequestBody Sucursal sucursal, @PathVariable int id){
        return service.updateSucursal(sucursal, id);
    }

    @DeleteMapping("/sucursales/eliminar/{id}")
    public String deleteSucursal (@PathVariable int id){
        return service.deleteSucursal(id);
    }
}