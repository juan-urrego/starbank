package com.starbank.controller;

import com.starbank.entity.Cuenta;
import com.starbank.service.CuentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CuentaController {

    @Autowired
    CuentaService service;

    @PostMapping("/cuentas/agregar")
    public Cuenta addCuenta(@RequestBody Cuenta cuenta){
        return  service.saveCuenta(cuenta);
    }

    @GetMapping("/cuentas")
    public List<Cuenta> findAllCuenta(){
        return  service.getCuentas();
    }

    @GetMapping("/cuentas/{id}")
    public Cuenta findCuentaById(@PathVariable int id){
        return service.getCuentaById(id);
    }

    @PutMapping("/cuentas/actualizar/{id}")
    public Cuenta updateCuenta(@RequestBody Cuenta cuenta, @PathVariable int id){
        return service.updateCuenta(cuenta, id);
    }


    @PutMapping("/cuentas/actualizar/{id}/consignar/{dinero}")
    public Cuenta consignarCuenta(@RequestBody Cuenta cuenta, @PathVariable int id, @PathVariable int dinero){
        return service.consignar(cuenta, id, dinero);
    }

    @PutMapping("/cuentas/actualizar/{id}/retirar/{dinero}")
    public Cuenta retirarCuenta(@RequestBody Cuenta cuenta, @PathVariable int id, @PathVariable int dinero){
        return service.retirar(cuenta, id, dinero);
    }



    @PutMapping("/cuentas/actualizar/{id}/estado/{estado}")
    public Cuenta desactivarCuenta(@RequestBody Cuenta cuenta, @PathVariable int id, @PathVariable String estado){
        return service.desactivar(cuenta, id, estado);
    }



    @DeleteMapping("/cuentas/eliminar/{id}")
    public String deleteCuenta (@PathVariable int id){
        return service.deleteCuenta(id);
    }
}
