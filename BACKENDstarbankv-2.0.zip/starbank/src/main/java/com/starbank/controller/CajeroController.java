package com.starbank.controller;

import com.starbank.entity.Cajero;
import com.starbank.service.CajeroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CajeroController {
    @Autowired
    CajeroService service;

    @PostMapping("/cajeros/agregar")
    public Cajero addCajero(@RequestBody Cajero cajero){
        return  service.saveCajero(cajero);
    }

    @GetMapping("/cajeros")
    public List<Cajero> findAllCajero(){
        return  service.getCajeros();
    }

    @GetMapping("/cajeros/{id}")
    public Cajero findCajeroById(@PathVariable int id){
        return service.getCajeroById(id);
    }

    @PutMapping("/cajeros/actualizar/{id}")
    public Cajero updateCajero(@RequestBody Cajero cajero, @PathVariable int id){
        return service.updateCajero(cajero, id);
    }

    @DeleteMapping("/cajeros/eliminar/{id}")
    public String deleteCajero (@PathVariable int id){
        return service.deleteCajero(id);
    }
}