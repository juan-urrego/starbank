package com.starbank.controller;

import com.starbank.entity.Cliente;
import com.starbank.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ClienteController {
    
    @Autowired
    ClienteService service;

    @PostMapping("/clientes/agregar")
    public Cliente addCliente(@RequestBody Cliente cliente){
        return  service.saveCliente(cliente);
    }

    @GetMapping("/clientes")
    public List<Cliente> findAllCliente(){
        return  service.getClientes();
    }

    @GetMapping("/clientes/nombre/{nombre}")
    public Cliente findClienteByName(@PathVariable String nombre){
        return service.getClienteByName(nombre);
    }

    @GetMapping("/clientes/{id}")
    public Cliente findClienteById(@PathVariable int id){
        return service.getClienteById(id);
    }

    @PutMapping("/clientes/actualizar/{id}")
    public Cliente updateCliente(@RequestBody Cliente cliente, @PathVariable int id){
        return service.updateCliente(cliente, id);
    }

    @DeleteMapping("/clientes/eliminar/{id}")
    public String deleteCliente (@PathVariable int id){
        return service.deleteCliente(id);
    }
}
