package com.starbank.controller;

import com.starbank.entity.Ahorro;
import com.starbank.service.AhorroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class AhorroController {
    @Autowired
    AhorroService service;

    @PostMapping("/ahorros/agregar")
    public Ahorro addAhorro(@RequestBody Ahorro ahorro){
        return  service.saveAhorro(ahorro);
    }

    @GetMapping("/ahorros")
    public List<Ahorro> findAllAhorro(){
        return  service.getAhorros();
    }

    @GetMapping("/ahorros/{id}")
    public Ahorro findAhorroById(@PathVariable int id){
        return service.getAhorroById(id);
    }

    @PutMapping("/ahorros/actualizar/{id}")
    public Ahorro updateAhorro(@RequestBody Ahorro ahorro, @PathVariable int id){
        return service.updateAhorro(ahorro,id);
    }

    @DeleteMapping("/ahorros/eliminar/{id}")
    public String deleteAhorro (@PathVariable int id){
        return service.deleteAhorro(id);
    }
}