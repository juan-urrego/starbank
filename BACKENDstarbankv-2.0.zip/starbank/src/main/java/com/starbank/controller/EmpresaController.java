package com.starbank.controller;

import com.starbank.entity.Empresa;
import com.starbank.service.EmpresaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EmpresaController {
    @Autowired
    EmpresaService service;

    @PostMapping("/empresas/agregar")
    public Empresa addEmpresa(@RequestBody Empresa empresa){
        return  service.saveEmpresa(empresa);
    }

    @GetMapping("/empresas")
    public List<Empresa> findAllEmpresa(){
        return  service.getEmpresas();
    }

    @GetMapping("/empresas/{id}")
    public Empresa findEmpresaById(@PathVariable int id){
        return service.getEmpresaById(id);
    }

    @PutMapping("/empresas/actualizar/{id}")
    public Empresa updateEmpresa(@RequestBody Empresa empresa, @PathVariable int id){
        return service.updateEmpresa(empresa, id);
    }

    @DeleteMapping("/empresas/eliminar/{id}")
    public String deleteEmpresa (@PathVariable int id){
        return service.deleteEmpresa(id);
    }
}
