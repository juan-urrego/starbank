package com.starbank.controller;

import com.starbank.entity.Operacion;
import com.starbank.service.OperacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class OperacionController {

    @Autowired
    OperacionService service;

    @PostMapping("/operaciones/agregar")
    public Operacion addOperacion(@RequestBody Operacion operacion){
        return  service.saveOperacion(operacion);
    }

    @GetMapping("/operaciones")
    public List<Operacion> findAllOperacion(){
        return  service.getOperaciones();
    }

    @GetMapping("/operaciones/{id}")
    public Operacion findOperacionById(@PathVariable int id){
        return service.getOperacionById(id);
    }

    @PutMapping("/operaciones/actualizar/{id}")
    public Operacion updateOperacion(@RequestBody Operacion operacion, @PathVariable int id){
        return service.updateOperacion(operacion, id);
    }

    @DeleteMapping("/operaciones/eliminar/{id}")
    public String deleteOperacion (@PathVariable int id){
        return service.deleteOperacion(id);
    }
}