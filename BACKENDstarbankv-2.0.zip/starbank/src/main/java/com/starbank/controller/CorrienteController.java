package com.starbank.controller;

import com.starbank.entity.Corriente;
import com.starbank.service.CorrienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CorrienteController {
    @Autowired
    CorrienteService service;

    @PostMapping("/corrientes/agregar")
    public Corriente addCorriente(@RequestBody Corriente corriente){
        return  service.saveCorriente(corriente);
    }

    @GetMapping("/corrientes")
    public List<Corriente> findAllCorriente(){
        return  service.getCorrientes();
    }

    @GetMapping("/corrientes/{id}")
    public Corriente findCorrienteById(@PathVariable int id){
        return service.getCorrienteById(id);
    }

    @PutMapping("/corrientes/actualizar/{id}")
    public Corriente updateCorriente(@RequestBody Corriente corriente, @PathVariable int id){
        return service.updateCorriente(corriente,id);
    }

    @DeleteMapping("/corrientes/eliminar/{id}")
    public String deleteCorriente (@PathVariable int id){
        return service.deleteCorriente(id);
    }
}