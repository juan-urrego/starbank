package com.starbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarbankApplication {

    public static void main(String[] args) {
        SpringApplication.run(StarbankApplication.class, args);
    }

}
