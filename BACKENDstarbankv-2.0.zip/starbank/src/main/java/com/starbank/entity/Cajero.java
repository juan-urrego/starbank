package com.starbank.entity;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
        import lombok.AllArgsConstructor;
        import lombok.Data;
        import lombok.NoArgsConstructor;

        import javax.persistence.*;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cajero")
public class Cajero {

    @Id
    @Column(name = "id_cajero")
    private int idCajero;
    private String direccion;

    //RELACION M:1, MUCHOS CAJEROS SON DE 1 SUCURSAL
    @JsonIgnoreProperties({"cuentas","cajeros"})
    @ManyToOne
    @JoinColumn(name = "sucursal_id_sucursal", nullable = false)
    private Sucursal sucursal;

    //Relacion con Operacion 1 a muchos
    @JsonIgnoreProperties({"cuenta","cajero"})
    @OneToMany(mappedBy = "cajero")
    private List<Operacion> operaciones;
}
