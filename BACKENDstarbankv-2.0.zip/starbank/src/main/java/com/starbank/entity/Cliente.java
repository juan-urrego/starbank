package com.starbank.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cliente")
public class Cliente {

    @Id
    @Column(name = "id_cliente")
    private int idCliente;
    private String nombre;
    private String ocupacion;
    private int telefono;

    //RELACION HERENCIA 1:M DE 1 CLIENTE SON MUCHAS PERSONAS
    @JsonIgnoreProperties({"cliente"})
    @OneToMany(mappedBy = "cliente")
    private List<Persona> personas;

    //RELACION HERENCIA DE 1:M DE 1 CLIENTE SON MUCHAS EMPRESAS
    @JsonIgnoreProperties({"cliente"})
    @OneToMany(mappedBy = "cliente")
    private List<Empresa> empresas;

    //RELACION DE 1:M DE 1 CLIENTE TIENE MUCHAS CUENTAS
    @JsonIgnoreProperties(value = {"cliente","ahorros","corrientes","operaciones","sucursal"})
    @OneToMany(mappedBy = "cliente")
    private List<Cuenta> cuentas;
}
