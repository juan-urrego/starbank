package com.starbank.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "empresa")
public class Empresa {

    @Id
    @Column(name = "id_empresa")
    private int idEmpresa;
    private String nit;
    private String nombre;
    private String sector;
    private String direccion;

    //RELACION HERENCIA CON CLIENTE
    @JsonIgnoreProperties({"personas","empresas","cuentas"})
    @ManyToOne
    @JoinColumn(name = "cliente_id_cliente", nullable = false)
    private Cliente cliente;
}
