package com.starbank.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cuenta")
public class Cuenta {

    @Id
    @Column(name = "id_cuenta")
    private  int idCuenta;
    private String titular;
    private int saldo;
    private String estado;
    private String tipo;

    //RELACION HERENCIA 1:M DE 1 CUENTA SON MUCHAS DE AHORROS
    @JsonIgnoreProperties({"cuenta"})
    @OneToMany(mappedBy = "cuenta")
    private List<Ahorro> ahorros;

    //RELACION HERENCIA 1:M DE 1 CUENTA SON MUCHAS DE CORRIENTE
    @JsonIgnoreProperties({"cuenta"})
    @OneToMany(mappedBy = "cuenta")
    private List<Corriente> corrientes;

    //RELACION DE M:1 CON EL CLIENTE, MUCHAS CUENTAS PUEDEN SER DE 1 CLIENTE
    @JsonIgnoreProperties({"personas","empresas","cuentas"})
    @ManyToOne
    @JoinColumn(name = "cliente_id_cliente", nullable = false)
    private Cliente cliente;

    //RELACION M:1 CON LA SUCURSAL, MUCHAS CUENTAS PUEDEN SER DE 1 SUCURSAL
    @JsonIgnoreProperties({"cuentas","cajeros"})
    @ManyToOne
    @JoinColumn(name = "sucursal_id_sucursal", nullable = false)
    private Sucursal sucursal;


    //Relacion con Operacion 1 a muchos
    @JsonIgnoreProperties({"cajero","cuenta"})
    @OneToMany(mappedBy = "cuenta")
    private List<Operacion> operaciones;
}
