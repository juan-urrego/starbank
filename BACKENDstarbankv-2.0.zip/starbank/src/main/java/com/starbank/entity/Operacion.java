package com.starbank.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "operacion")
public class Operacion {

    @Id
    @Column(name = "id_operacion")
    private int idOperacion;
    private String nombre;
    private String fecha;
    private String hora;


    //Relacion con cuenta
    @JsonIgnoreProperties(value = {"ahorros","corrientes","operaciones","cliente","sucursal"}, allowSetters = true)
    @ManyToOne
    @JoinColumn(name = "Cuenta_idCuenta", nullable = false)
    private Cuenta cuenta;

    //Relacion con cuenta
    @JsonIgnoreProperties({"sucursal","operaciones"})
    @ManyToOne
    @JoinColumn(name = "Cajero_idCajero", nullable = false)
    private Cajero cajero;

}
