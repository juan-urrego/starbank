package com.starbank.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ahorro")
public class Ahorro {

    @Id
    @Column(name = "id_ahorro")
    private int idAhorro;
    private double intereses;

    //RELACION HERENCIA CON CUENTA

    @ManyToOne
    @JoinColumn(name = "cuentas_id_cuenta", nullable = false)
    private Cuenta cuenta;
}
