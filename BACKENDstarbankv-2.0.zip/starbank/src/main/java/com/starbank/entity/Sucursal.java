package com.starbank.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "sucursal")
public class Sucursal {

    @Id
    @Column(name = "id_sucursal")
    private int idSucursal;
    private String nombre;
    private String direccion;
    private String ciudad;
    private double saldo;

    //RELACION 1:1 UNA SUCURSAL TIENE 1 CUENTA CORRIENTE
//    @JsonManagedReference(value = "cuenta_sucursal")
//    @OneToOne
//    @JoinColumn(name = "corriente_id_corriente", nullable = false)
//    private Corriente corriente;

    //RELACION 1:M, UNA SUCURSAL TIENE MUCHAS CUENTAS
    @JsonIgnoreProperties({"operaciones","sucursal","cliente","corrientes","ahorros"})
    @OneToMany(mappedBy = "sucursal")
    private List<Cuenta> cuentas;

    //RELACION 1:M, UNA SUCURSAL TIENE MUCHOS CAJEROS

    @JsonIgnoreProperties({"sucursal","operaciones"})
    @OneToMany(mappedBy = "sucursal")
    private List<Cajero> cajeros;
}
