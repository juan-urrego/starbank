package com.starbank.service;

import com.starbank.entity.Corriente;
import com.starbank.repository.CorrienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CorrienteService {

    @Autowired
    CorrienteRepository repository;

    public Corriente saveCorriente(Corriente corriente){
        return repository.save(corriente);
    }

    public List<Corriente> getCorrientes(){
        return repository.findAll();
    }

    public Corriente getCorrienteById(int id){
        return repository.findById(id).orElse(null);
    }

    public String deleteCorriente(int id){
        repository.deleteById(id);
        return "corriente eliminado " + id;
    }

    public Corriente updateCorriente(Corriente corrienteExistente, int id){
        return repository.findById(id)
                .map(corriente -> {
                    corriente.setCuenta(corrienteExistente.getCuenta());
                    return repository.save(corriente);
                })
                .orElse(null);
    }
}