package com.starbank.service;

import com.starbank.entity.Ahorro;
import com.starbank.repository.AhorroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AhorroService {

    @Autowired
    AhorroRepository repository;

    public Ahorro saveAhorro(Ahorro ahorro){
        return repository.save(ahorro);
    }

    public List<Ahorro> getAhorros(){
        return repository.findAll();
    }

    public Ahorro getAhorroById(int id){
        return repository.findById(id).orElse(null);
    }

    public String deleteAhorro(int id){
        repository.deleteById(id);
        return "ahorro eliminado " + id;
    }

    public Ahorro updateAhorro(Ahorro ahorroExistente, int id){
        return repository.findById(id)
                .map(ahorro -> {
                    ahorro.setIntereses(ahorroExistente.getIntereses());
                    ahorro.setCuenta(ahorroExistente.getCuenta());
                    return repository.save(ahorro);
                })
                .orElse(null);
    }
}
