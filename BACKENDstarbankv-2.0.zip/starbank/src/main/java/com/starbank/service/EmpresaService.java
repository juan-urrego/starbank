package com.starbank.service;

import com.starbank.entity.Empresa;
import com.starbank.repository.EmpresaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmpresaService {

    @Autowired
    EmpresaRepository repository;

    public Empresa saveEmpresa(Empresa empresa){
        return repository.save(empresa);
    }

    public List<Empresa> getEmpresas(){
        return repository.findAll();
    }

    public Empresa getEmpresaById(int id){
        return repository.findById(id).orElse(null);
    }

    public String deleteEmpresa(int id){
        repository.deleteById(id);
        return "empresa eliminado " + id;
    }

    public Empresa updateEmpresa(Empresa empresaExistente, int id){
        return repository.findById(id)
                .map(empresa -> {
                    empresa.setNit(empresaExistente.getNit());
                    empresa.setNombre(empresaExistente.getNombre());
                    empresa.setSector(empresaExistente.getSector());
                    empresa.setDireccion(empresaExistente.getDireccion());
                    empresa.setCliente(empresaExistente.getCliente());
                    return repository.save(empresa);
                })
                .orElse(null);
    }
}
