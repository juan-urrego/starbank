package com.starbank.service;

import com.starbank.entity.Cuenta;
import com.starbank.repository.CuentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CuentaService {

    @Autowired
    CuentaRepository repository;

    public Cuenta saveCuenta(Cuenta cuenta){
        return repository.save(cuenta);
    }

    public List<Cuenta> getCuentas(){
        return repository.findAll();
    }

    public Cuenta getCuentaById(int id){
        return repository.findById(id).orElse(null);
    }

    public String deleteCuenta(int id){
        repository.deleteById(id);
        return "cuenta eliminado " + id;
    }

    public Cuenta updateCuenta(Cuenta cuentaExistente, int id){
        return repository.findById(id)
                .map(cuenta -> {
                    cuenta.setTitular(cuentaExistente.getTitular());
                    cuenta.setSaldo(cuentaExistente.getSaldo());
                    cuenta.setEstado(cuentaExistente.getEstado());
                    cuenta.setCliente(cuentaExistente.getCliente());
                    cuenta.setSucursal(cuentaExistente.getSucursal());
                    return repository.save(cuenta);
                })
                .orElse(null);
    }

    public Cuenta consignar(Cuenta cuentaExistente, int id, int dinero){
        return repository.findById(id)
                .map(cuenta -> {
                    cuenta.setTitular(cuentaExistente.getTitular());
                    cuenta.setSaldo(cuentaExistente.getSaldo() + dinero);
                    cuenta.setEstado(cuentaExistente.getEstado());
                    cuenta.setCliente(cuentaExistente.getCliente());
                    cuenta.setSucursal(cuentaExistente.getSucursal());
                    return repository.save(cuenta);
                })
                .orElse(null);
    }

    public Cuenta retirar(Cuenta cuentaExistente, int id, int dinero){
        return repository.findById(id)
                .map(cuenta -> {
                    cuenta.setTitular(cuentaExistente.getTitular());
                    cuenta.setSaldo(cuentaExistente.getSaldo() - dinero);
                    cuenta.setEstado(cuentaExistente.getEstado());
                    cuenta.setCliente(cuentaExistente.getCliente());
                    cuenta.setSucursal(cuentaExistente.getSucursal());
                    return repository.save(cuenta);
                })
                .orElse(null);
    }

    public Cuenta desactivar(Cuenta cuentaExistente, int id, String estado){
        return repository.findById(id)
                .map(cuenta -> {
                    cuenta.setTitular(cuentaExistente.getTitular());
                    cuenta.setSaldo(cuentaExistente.getSaldo());
                    cuenta.setEstado(estado);
                    cuenta.setCliente(cuentaExistente.getCliente());
                    cuenta.setSucursal(cuentaExistente.getSucursal());
                    return repository.save(cuenta);
                })
                .orElse(null);
    }

}
