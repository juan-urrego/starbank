package com.starbank.service;

import com.starbank.entity.Cajero;
import com.starbank.repository.CajeroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CajeroService {

    @Autowired
    CajeroRepository repository;

    public Cajero saveCajero(Cajero cajero){
        return repository.save(cajero);
    }

    public List<Cajero> getCajeros(){
        return repository.findAll();
    }

    public Cajero getCajeroById(int id){
        return repository.findById(id).orElse(null);
    }

    public String deleteCajero(int id){
        repository.deleteById(id);
        return "cajero eliminado " + id;
    }

    public Cajero updateCajero(Cajero cajeroExistente, int id){
        return repository.findById(id)
                .map(cajero -> {
                    cajero.setDireccion(cajeroExistente.getDireccion());
                    cajero.setSucursal(cajeroExistente.getSucursal());
                    return repository.save(cajero);
                })
                .orElse(null);
    }
}
