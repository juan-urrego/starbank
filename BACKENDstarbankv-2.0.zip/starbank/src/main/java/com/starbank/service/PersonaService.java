package com.starbank.service;

import com.starbank.entity.Persona;
import com.starbank.repository.PersonaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonaService {
    
    @Autowired
    PersonaRepository repository;

    public Persona savePersona(Persona persona){
        return repository.save(persona);
    }

    public List<Persona> getPersonas(){
        return repository.findAll();
    }

    public Persona getPersonaById(int id){
        return repository.findById(id).orElse(null);
    }

    public String deletePersona(int id){
        repository.deleteById(id);
        return "persona eliminado " + id;
    }

    public Persona updatePersona(Persona personaExistente, int id){
        return repository.findById(id)
                .map(persona -> {
                    persona.setDireccion(personaExistente.getDireccion());
                    persona.setCliente(personaExistente.getCliente());
                    return repository.save(persona);
                })
                .orElse(null);
    }
}
