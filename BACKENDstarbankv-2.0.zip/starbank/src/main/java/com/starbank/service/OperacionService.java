package com.starbank.service;

import com.starbank.entity.Operacion;
import com.starbank.repository.OperacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OperacionService {

    @Autowired
    OperacionRepository repository;

    public Operacion saveOperacion(Operacion operacion){
        return repository.save(operacion);
    }

    public List<Operacion> getOperaciones(){
        return repository.findAll();
    }

    public Operacion getOperacionById(int id){
        return repository.findById(id).orElse(null);
    }

    public String deleteOperacion(int id){
        repository.deleteById(id);
        return "operacion eliminado " + id;
    }

    public Operacion updateOperacion(Operacion operacionExistente, int id){
        return repository.findById(id)
                .map(operacion -> {
                    operacion.setNombre(operacionExistente.getNombre());
                    operacion.setFecha(operacionExistente.getFecha());
                    operacion.setHora(operacionExistente.getHora());
                    operacion.setCuenta(operacionExistente.getCuenta());
                    operacion.setCajero(operacionExistente.getCajero());
                    return repository.save(operacion);
                })
                .orElse(null);
    }
}
