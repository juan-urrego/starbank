package com.starbank.service;

import com.starbank.entity.Sucursal;
import com.starbank.repository.SucursalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SucursalService {

    @Autowired
    SucursalRepository repository;

    public Sucursal saveSucursal(Sucursal sucursal){
        return repository.save(sucursal);
    }

    public List<Sucursal> getSucursals(){
        return repository.findAll();
    }

    public Sucursal getSucursalById(int id){
        return repository.findById(id).orElse(null);
    }

    public String deleteSucursal(int id){
        repository.deleteById(id);
        return "sucursal eliminado " + id;
    }

    public Sucursal updateSucursal(Sucursal sucursalExistente, int id){
        return repository.findById(id)
                .map(sucursal -> {
                    sucursal.setNombre(sucursalExistente.getNombre());
                    sucursal.setDireccion(sucursalExistente.getDireccion());
                    sucursal.setCiudad(sucursalExistente.getCiudad());
                    return repository.save(sucursal);
                })
                .orElse(null);
    }
}
