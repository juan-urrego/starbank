package com.starbank.service;

import com.starbank.entity.Cliente;
import com.starbank.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClienteService {

    @Autowired
    ClienteRepository repository;

    public Cliente saveCliente(Cliente cliente){
        return repository.save(cliente);
    }

    public List<Cliente> getClientes(){
        return repository.findAll();
    }

    public Cliente getClienteByName(String nombre){
        return repository.findByNombre(nombre);
    }

    public Cliente getClienteById(int id){
        return repository.findById(id).orElse(null);
    }

    public String deleteCliente(int id){
        repository.deleteById(id);
        return "cliente eliminado " + id;
    }

    public Cliente updateCliente(Cliente clienteExistente, int id){
        return repository.findById(id)
                .map(cliente -> {
                    cliente.setNombre(clienteExistente.getNombre());
                    cliente.setOcupacion(clienteExistente.getOcupacion());
                    cliente.setTelefono(clienteExistente.getTelefono());
                    return repository.save(cliente);
                })
                .orElse(null);
    }
}
